import React from 'react';
import 'bootstrap/dist/css/bootstrap.css'

import Entries from './components/entries.components'


function App() {
  return (
    <div>
      <Entries />
    </div>
  );
}

export default App;
